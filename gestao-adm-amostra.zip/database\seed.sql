-- Gestao ADM. - Dados iniciais para demonstracao
-- Execute depois do schema.sql

insert into departments (name)
values
  ('Administrativo'),
  ('Financeiro'),
  ('Comercial'),
  ('Operacoes'),
  ('RH')
on conflict (name) do nothing;

insert into competencies (name, description)
values
  ('Comunicacao', 'Clareza na troca de informacoes entre pessoas e setores.'),
  ('Organizacao', 'Controle de tarefas, rotina e prioridades.'),
  ('Trabalho em equipe', 'Cooperacao e colaboracao com colegas.'),
  ('Lideranca', 'Capacidade de orientar e apoiar pessoas.'),
  ('Resolucao de problemas', 'Autonomia para resolver dificuldades.'),
  ('Proatividade', 'Iniciativa sem depender sempre de solicitacao.'),
  ('Gestao de tempo', 'Cumprimento de prazos e organizacao da agenda.')
on conflict (name) do nothing;

insert into questions (competency_id, question_text)
select id, 'Voce consegue se comunicar bem com outros setores?'
from competencies
where name = 'Comunicacao'
on conflict do nothing;

insert into questions (competency_id, question_text)
select id, 'Voce entende claramente suas tarefas antes de inicia-las?'
from competencies
where name = 'Comunicacao'
on conflict do nothing;

insert into questions (competency_id, question_text)
select id, 'Voce consegue manter suas atividades organizadas?'
from competencies
where name = 'Organizacao'
on conflict do nothing;

insert into questions (competency_id, question_text)
select id, 'Seus prazos costumam ser cumpridos?'
from competencies
where name = 'Gestao de tempo'
on conflict do nothing;

insert into questions (competency_id, question_text)
select id, 'Voce coopera com colegas para resolver problemas?'
from competencies
where name = 'Trabalho em equipe'
on conflict do nothing;

insert into questions (competency_id, question_text)
select id, 'Voce tenta resolver dificuldades antes de repassar a demanda?'
from competencies
where name = 'Resolucao de problemas'
on conflict do nothing;

